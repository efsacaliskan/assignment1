#include "SelectionAlgorithm.h"
#include <iostream>

using namespace std;

SelectionAlgorithm::SelectionAlgorithm(int k) {
    this->k = k;
}

int SelectionAlgorithm::select() {
    return 0;
}